package com.SamuelDTO.senai.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.SamuelDTO.senai.entities.Livro;

public interface LivroRepository extends JpaRepository<Livro, Long>{

	
}
