package com.SamuelDTO.senai.dto;

public record LivroDTO(Long id, String titulo, String autor) {

}
